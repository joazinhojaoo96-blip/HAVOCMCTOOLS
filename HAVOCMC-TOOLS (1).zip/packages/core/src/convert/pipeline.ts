import { readZipDetailed, writeZip } from "../io/zip.js";
import { VirtualFs } from "../io/vfs.js";
import { JavaPack } from "../java/javaPack.js";
import { mergeJavaPacks } from "../java/mergePacks.js";
import { ConversionReport } from "../report/report.js";
import { Timings, beginTimings, finishTimings } from "../report/timings.js";
import {
  DEFAULT_OPTIONS,
  type ConversionContext,
  type ConvertOptions,
  type PipelineStage,
  type ProgressCallback,
} from "./context.js";
import { texturesStage } from "./stages/texturesStage.js";
import { entityCompositesStage } from "./stages/entityCompositesStage.js";
import { itemsStage } from "./stages/itemsStage.js";
import { bowPullStage } from "./stages/bowPullStage.js";
import { geometryStage } from "./stages/geometryStage.js";
import { armorStage } from "./stages/armorStage.js";
import { flipbooksStage } from "./stages/flipbooksStage.js";
import { soundsStage } from "./stages/soundsStage.js";
import { langStage } from "./stages/langStage.js";
import { fontsStage } from "./stages/fontsStage.js";
import { paintingsStage } from "./stages/paintingsStage.js";
import { blocksStage } from "./stages/blocksStage.js";
import { packagingStage } from "./stages/packagingStage.js";
import { optimizeStage } from "./stages/optimizeStage.js";
import { buildModelEngineInput } from "../modelengine/modelEngineInput.js";

export interface ConvertResult {
  /** Bedrock resource pack (.mcpack = zip). */
  mcpack: Uint8Array;
  /** geyser_mappings.json contents (undefined when no custom items were found). */
  geyserMappings: string | undefined;
  /** geyser_blocks.json contents, format_version 1 (undefined when no custom blocks). */
  geyserBlockMappings: string | undefined;
  /**
   * GeyserDisplayEntity extension mappings YAML (undefined when no furniture
   * items were found). Goes in extensions/geyserdisplayentity/Mappings/.
   */
  displayEntityMappings: string | undefined;
  /**
   * Recommended GeyserDisplayEntity `config.yml`, emitted only when furniture
   * maps onto a base item the extension hides by default (e.g.
   * leather_horse_armor). Goes in extensions/geyserdisplayentity/config.yml —
   * without it, furniture on those items shows for a frame then vanishes.
   */
  displayEntityConfig: string | undefined;
  /**
   * GeyserModelEngine `input/` bundle (zip) — the per-model folders (Bedrock
   * geometry + animations + textures + config.json) built from any `.bbmodel`
   * ModelEngine/MythicMobs blueprints in the upload. Undefined when none found.
   * Unzip into `extensions/geysermodelengineextension/input/` and reload Geyser.
   */
  modelEngineInput: Uint8Array | undefined;
  report: ReturnType<ConversionReport["toJSON"]>;
  /** Per-stage and hot-op timing breakdown for performance analysis. */
  timings: ReturnType<Timings["toJSON"]>;
}

/**
 * Cap on individually-listed merge conflicts. A pack pair overriding the same
 * base can collide on thousands of paths; the tail is summarised as a count so
 * the report stays readable.
 */
const MAX_REPORTED_CONFLICTS = 40;

/** Same idea for keys two packs both defined inside one merged file. */
const MAX_REPORTED_SHADOWED_KEYS = 12;

/** Stages run in order; later milestones insert stages between textures and packaging. */
const STAGES: PipelineStage[] = [
  texturesStage,
  entityCompositesStage,
  itemsStage,
  bowPullStage,
  geometryStage,
  armorStage,
  blocksStage,
  flipbooksStage,
  soundsStage,
  langStage,
  fontsStage,
  paintingsStage,
  packagingStage,
  optimizeStage,
];

/**
 * Convert one Java pack, or merge several into one Bedrock pack.
 *
 * Servers commonly run a stack of resource packs, but a Bedrock client can only
 * be sent a single one — so passing an array merges them first (see
 * {@link mergeJavaPacks}) and converts the combined tree. Priority is list
 * order, first wins.
 */
export async function convertPack(
  zipBytes: Uint8Array | Uint8Array[],
  options?: Partial<ConvertOptions>,
  progress?: ProgressCallback,
): Promise<ConvertResult> {
  const packs = Array.isArray(zipBytes) ? zipBytes : [zipBytes];
  const packNames = options?.packNames ?? [];
  const merge = mergeJavaPacks(
    packs.map((bytes, i) => ({ name: packNames[i] ?? `pack ${i + 1}`, bytes })),
  );
  const inputVfs = merge.vfs;
  const unreadable = merge.unreadable.map((u) => ({ name: u.name, reason: u.reason }));
  // Every upload failed to open, or they opened empty. Merging turned what used
  // to be a thrown error into a silently "successful" empty pack, so fail loudly
  // here instead of handing the user a downloadable pack with nothing in it.
  if (inputVfs.size === 0) {
    const why =
      merge.failedPacks.length > 0
        ? `could not read ${merge.failedPacks.join(", ")} — not a zip/mcpack archive, or corrupt`
        : "the upload contained no files";
    throw new Error(`Nothing to convert: ${why}`);
  }
  const java = JavaPack.open(inputVfs);
  // An upload with neither an assets tree nor a pack.mcmeta is not a resource
  // pack — a config zip, or a parent directory picked by mistake. It converts
  // to nothing, and returning an empty pack for it looks like success and sends
  // the user off to install it, so name the likely mistake instead. A pack that
  // declares itself and happens to be empty is still a pack, and passes.
  if (java.namespaces().length === 0 && inputVfs.list({ suffix: "pack.mcmeta" }).length === 0) {
    const names = packNames.filter((n) => n !== "").join(", ");
    throw new Error(
      `Nothing to convert: ${names !== "" ? `${names} has` : "the upload has"} no assets folder and no pack.mcmeta. ` +
        `Upload the resource pack itself — the zip or folder that contains assets/ — not a plugin config or a parent directory.`,
    );
  }

  const opts: ConvertOptions = {
    packName: options?.packName ?? "Converted Pack",
    packNames: options?.packNames ?? DEFAULT_OPTIONS.packNames,
    attachableMaterial: options?.attachableMaterial ?? DEFAULT_OPTIONS.attachableMaterial,
    animate2dHeldItems: options?.animate2dHeldItems ?? DEFAULT_OPTIONS.animate2dHeldItems,
    namespaces: options?.namespaces ?? DEFAULT_OPTIONS.namespaces,
    modernBaseItem: options?.modernBaseItem ?? DEFAULT_OPTIONS.modernBaseItem,
    baseItemHints: options?.baseItemHints ?? DEFAULT_OPTIONS.baseItemHints,
    displayNameHints: options?.displayNameHints ?? DEFAULT_OPTIONS.displayNameHints,
    equippableHints: options?.equippableHints ?? DEFAULT_OPTIONS.equippableHints,
    cmdItemKeys: options?.cmdItemKeys ?? DEFAULT_OPTIONS.cmdItemKeys,
    colorHints: options?.colorHints ?? DEFAULT_OPTIONS.colorHints,
    backpackItems: options?.backpackItems ?? DEFAULT_OPTIONS.backpackItems,
    furnitureItems: options?.furnitureItems ?? DEFAULT_OPTIONS.furnitureItems,
    furnitureTransforms: options?.furnitureTransforms ?? DEFAULT_OPTIONS.furnitureTransforms,
    configZipProvided: options?.configZipProvided ?? false,
    maxAnimationFrames: options?.maxAnimationFrames ?? DEFAULT_OPTIONS.maxAnimationFrames,
    optimizePack: options?.optimizePack ?? DEFAULT_OPTIONS.optimizePack,
    maxCompression: options?.maxCompression ?? DEFAULT_OPTIONS.maxCompression,
    recompressor: options?.recompressor,
    pngEncoder: options?.pngEncoder,
  };

  const timings = new Timings();
  const ctx: ConversionContext = {
    java,
    bedrock: new VirtualFs(opts.optimizePack),
    options: opts,
    report: new ConversionReport(),
    timings,
    progress: progress ?? (() => {}),
    itemTextures: new Map(),
    terrainTextures: new Map(),
    geyserMappings: { format_version: 2, items: {} },
    geyserBlocks: {},
    pendingGeometry: [],
    bowPullGroups: [],
    fallbackBaseItemHits: 0,
    configZipProvided: false,
    definitionTextures: new Map(),
    usedBedrockIdentifiers: new Set(),
    textureCache: new Map(),
    geometryHandledTextures: new Set(),
    displayEntityMappings: [],
    inferredHostItems: new Map(),
    definitionHostItems: new Map(),
    resolvedModels: new Map(),
  };
  ctx.configZipProvided = opts.configZipProvided === true;

  for (const entry of unreadable) {
    ctx.report.error("ingest", entry.name, `could not extract from zip: ${entry.reason}`);
  }

  // Merge accounting. Only reported when several packs were combined — a single
  // pack has nothing to collide with and nothing to say.
  if (merge.packs.length > 1) {
    ctx.report.converted(
      "merge",
      `${merge.packs.length} resource packs merged`,
      merge.packs.map((p, i) => `${i + 1}. ${p.name} — ${p.files} file(s)`),
    );
    for (const file of merge.mergedFiles) {
      if (file.shadowedKeys.length === 0) {
        ctx.report.converted("merge", file.path, [
          `combined from ${file.sources} packs — entries from every pack kept`,
        ]);
        continue;
      }
      // The union kept every key, but a key two packs both defined can only
      // hold one value. Name them: this is how a wrong item name or a silent
      // sound in game gets explained.
      const names = file.shadowedKeys.slice(0, MAX_REPORTED_SHADOWED_KEYS);
      ctx.report.approximated(
        "merge",
        file.path,
        `combined from ${file.sources} packs, but ${file.shadowedKeys.length} key(s) were ` +
          `defined by more than one pack and kept the first pack's value: ` +
          `${names.join(", ")}${file.shadowedKeys.length > names.length ? ", …" : ""}. ` +
          `Reorder the uploads to change which one wins.`,
      );
    }
    // Same path in more than one pack: only one copy can ship. Say so, because
    // in game this looks like a texture that simply failed to apply.
    const shown = merge.conflicts.slice(0, MAX_REPORTED_CONFLICTS);
    for (const conflict of shown) {
      ctx.report.approximated(
        "merge",
        conflict.path,
        `defined by ${conflict.overridden.length + 1} packs — kept "${conflict.kept}", ` +
          `overrode ${conflict.overridden.map((n) => `"${n}"`).join(", ")}. ` +
          `Reorder the uploads to change which one wins.`,
      );
    }
    if (merge.conflicts.length > shown.length) {
      ctx.report.approximated(
        "merge",
        `${merge.conflicts.length - shown.length} more conflicting path(s)`,
        `listed the first ${MAX_REPORTED_CONFLICTS}; all resolved the same way (first pack wins)`,
      );
    }
  }

  const now = (): number =>
    typeof globalThis.performance?.now === "function" ? globalThis.performance.now() : Date.now();
  beginTimings(timings);
  try {
    for (const stage of STAGES) {
      ctx.progress(stage.name, 0, 1);
      const start = now();
      try {
        await stage.run(ctx);
      } catch (err) {
        ctx.report.error(stage.name, "(stage)", err instanceof Error ? err.message : String(err));
      }
      timings.stage(stage.name, now() - start);
      ctx.progress(stage.name, 1, 1);
    }
  } finally {
    finishTimings();
  }

  // Anything still pending after all stages ran was not consumed by the
  // geometry stage — this should never happen (the stage drains the queue),
  // so flag it as an internal error rather than a missing feature.
  for (const pending of ctx.pendingGeometry) {
    ctx.report.skipped(
      "items-3d",
      `${pending.variant.origin} → ${pending.variant.model}`,
      "internal error: 3D variant not consumed by the geometry stage",
    );
  }

  if (ctx.displayEntityMappings.length > 0) {
    ctx.report.converted(
      "furniture",
      `${ctx.displayEntityMappings.length} furniture item(s) from plugin configs`,
      ["geyser_displayentity_mappings.yml — install the GeyserDisplayEntity extension to show furniture on Bedrock"],
    );
  }

  // Config-zip nudge: warn when many modern items fell back to a generic base
  // item and no plugin config zip was provided to resolve real host items.
  if (ctx.fallbackBaseItemHits >= 2 && !ctx.configZipProvided) {
    ctx.report.approximated(
      "config-nudge",
      `${ctx.fallbackBaseItemHits} modern item-model assets`,
      `${ctx.fallbackBaseItemHits} modern item-model assets were mapped under ${ctx.options.modernBaseItem} because their host item isn't declared in the pack. Upload your Oraxen/Nexo/ItemsAdder/CraftEngine config zip (under Plugin config zips above) to get real base items and display names.`,
    );
  }

  // ModelEngine / MythicMobs: convert any .bbmodel blueprints in the upload to
  // the GeyserModelEngine input bundle. Scan the main pack AND any plugin config
  // zips (blueprints often ship in the ModelEngine plugin folder, not the RP).
  const meSources = [inputVfs];
  for (const zip of options?.pluginConfigZips ?? []) {
    try {
      meSources.push(readZipDetailed(zip).vfs);
    } catch {
      // Unreadable config zip — main-pack scan still runs.
    }
  }
  const meResult = buildModelEngineInput(meSources);
  let modelEngineInput: Uint8Array | undefined;
  if (meResult.models.length > 0) {
    const meVfs = new VirtualFs();
    for (const [path, bytes] of meResult.files) meVfs.write(path, bytes);
    modelEngineInput = writeZip(meVfs);
    ctx.report.converted(
      "modelengine",
      `${meResult.models.length} ModelEngine model(s) from .bbmodel blueprints`,
      [
        "modelengine_input.zip — unzip into extensions/geysermodelengineextension/input/ (needs the GeyserModelEngine extension + plugin)",
        ...meResult.models.map((m) => `${m.id}: ${m.textures} texture(s), ${m.animations} animation(s)`),
      ],
    );
  }
  for (const f of meResult.failed) ctx.report.skipped("modelengine", f.source, f.reason);

  const hasMappings = Object.keys(ctx.geyserMappings.items).length > 0;
  const hasBlocks = Object.keys(ctx.geyserBlocks).length > 0;
  const zipStart = now();
  const mcpack = writeZip(ctx.bedrock);
  timings.stage("zip.write", now() - zipStart);
  return {
    mcpack,
    geyserMappings: hasMappings ? JSON.stringify(ctx.geyserMappings, null, 2) : undefined,
    geyserBlockMappings: hasBlocks
      ? JSON.stringify({ format_version: 1, blocks: ctx.geyserBlocks }, null, 2)
      : undefined,
    displayEntityMappings:
      ctx.displayEntityMappings.length > 0
        ? buildDisplayEntityYaml(ctx.displayEntityMappings)
        : undefined,
    displayEntityConfig:
      ctx.displayEntityMappings.length > 0
        ? buildDisplayEntityConfig(new Set(ctx.displayEntityMappings.map((e) => e.type)))
        : undefined,
    modelEngineInput,
    report: ctx.report.toJSON(),
    timings: timings.toJSON(),
  };
}

/**
 * GeyserDisplayEntity extension mappings YAML for furniture items. The
 * extension equips the (already converted) custom item on a stand-in entity
 * wherever the server spawns an item_display, so Bedrock players see
 * furniture; per-item options let testers tune offsets.
 */
function buildDisplayEntityYaml(
  entries: {
    key: string;
    type: string;
    identifier: string;
    modelData?: number;
    vanillaScale?: boolean;
    scaleMultiplier?: number;
    yOffset?: number;
  }[],
): string {
  const lines = [
    "# GeyserDisplayEntity mappings — generated by GeyserConverter.",
    "# Requires the GeyserDisplayEntity Geyser extension:",
    "#   https://github.com/GeyserExtensionists/GeyserDisplayEntity",
    "# Install: drop the extension jar in Geyser's extensions/ folder, then put",
    "# this file in extensions/geyserdisplayentity/Mappings/.",
    "#",
    "# Placement — rotation, height and (when enabled) scale — is applied at",
    "# runtime by the extension reading the server's item_display entity. The",
    "# pack ships only raw geometry; nothing is baked. This mirrors how",
    "# production furniture packs convert 1:1, so a chair the server places",
    "# stands upright and sits at the right height without per-item tuning.",
    "#",
    "# The exception is scale. A piece the plugin places with a display",
    "# transform (FIXED, HEAD) picks up that entry from the model on Java —",
    "# routinely a 1.7-3x enlargement the model is authored to rely on — and",
    "# Bedrock has no client-side display transform, so it would render that",
    "# much too small. vanilla-scale + vanilla-scale-multiplier put it back: the",
    "# extension sets the Bedrock entity scale to the plugin's own scale times",
    "# the multiplier, and the multiplier is the model's display scale, so the",
    "# product is the Java size. Furniture placed with NONE needs no correction",
    "# and leaves vanilla-scale off.",
    "#",
    "# y-offset is 0 for furniture the extension repositions live; NONE-transform",
    "# furniture (no runtime transform) gets a negative y-offset so it's seated",
    "# instead of hanging at the item anchor. The global default y-offset (-0.5)",
    "# lives in config.yml. If a piece still floats, lower its y-offset here; if",
    "# it sinks, raise it.",
    "mappings:",
  ];
  for (const e of entries) {
    lines.push(`  ${e.key}:`);
    lines.push(`    type: "${e.type}"`);
    if (e.modelData !== undefined) {
      lines.push(`    model-data: ${e.modelData}`);
      lines.push(`    item-identifier: "none"`);
    } else {
      lines.push(`    item-identifier: "${e.identifier}"`);
    }
    const vanilla = e.vanillaScale ?? false;
    lines.push("    displayentityoptions:");
    lines.push(`      y-offset: ${(e.yOffset ?? 0).toFixed(3)}`);
    lines.push(`      vanilla-scale: ${vanilla}`);
    lines.push(`      vanilla-scale-multiplier: ${vanilla ? (e.scaleMultiplier ?? 1).toFixed(4) : 0}`);
    lines.push("      hand: false");
  }
  return lines.join("\n") + "\n";
}

/**
 * GeyserDisplayEntity config.yml. The global `y-offset` (-0.5) and `height`
 * (1.7) here are what seat furniture on the floor — the per-item mappings keep
 * y-offset 0 and rely on these. Without a matching config the stand-in entity
 * renders the model at chest height, so furniture floats ~1 block up. This
 * mirrors the config a production 1:1 furniture server runs, so we always emit
 * it alongside the mappings. `hide-types` (default minecraft:bone) hides stray
 * vanilla item-displays; any furniture base item that lands in it is removed so
 * the furniture isn't hidden too.
 */
const HIDE_TYPE_DEFAULTS = ["minecraft:bone"];

function buildDisplayEntityConfig(furnitureBaseItems: Set<string>): string {
  const hideTypes = HIDE_TYPE_DEFAULTS.filter((t) => !furnitureBaseItems.has(t));
  const yamlList = (items: string[]): string =>
    items.length === 0 ? " []" : "\n" + items.map((t) => `  - "${t}"`).join("\n");
  return [
    "# GeyserDisplayEntity config.yml — generated by GeyserConverter.",
    "# Drop this in extensions/geyserdisplayentity/config.yml (back up your own",
    "# first if you've customised it). The general values below seat furniture on",
    "# the floor — y-offset/height compensate for the stand-in entity's chest",
    "# anchor. Without them furniture floats ~1 block up. hide-types hides stray",
    "# vanilla item-displays; this converter's furniture base items are removed",
    "# from it so they render instead of being hidden.",
    "general:",
    "  use-legacy-models: true",
    "  height: 1.7",
    "  y-offset: -0.5",
    "  vanilla-scale: false",
    "  vanilla-scale-multiplier: 1",
    "  hand: false",
    `hide-types:${yamlList(hideTypes)}`,
    "",
  ].join("\n");
}
